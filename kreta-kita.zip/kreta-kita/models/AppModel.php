<?php
// ============================================================
// KRETA KITA — models/AppModel.php
// All database queries (PDO prepared statements)
// ============================================================

class AppModel {

    // ── USERS ─────────────────────────────────────────────────
    public function getUserByEmail(string $email): array|false {
        $st = db()->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $st->execute([$email]);
        return $st->fetch();
    }
    public function getUserById(int $id): array|false {
        $st = db()->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
        $st->execute([$id]);
        return $st->fetch();
    }
    public function createUser(string $name, string $email, string $password): bool {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $st = db()->prepare("INSERT INTO users (name,email,password,role) VALUES (?,?,?,'user')");
        return $st->execute([$name, $email, $hash]);
    }
    public function countUsers(): int {
        return (int)db()->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
    }
    public function getAllUsers(): array {
        return db()->query("SELECT id,name,email,role,created_at FROM users ORDER BY id DESC")->fetchAll();
    }

    // ── TRAINS ────────────────────────────────────────────────
    public function getAllTrains(): array {
        return db()->query("SELECT * FROM trains ORDER BY id DESC")->fetchAll();
    }
    public function getTrainById(int $id): array|false {
        $st = db()->prepare("SELECT * FROM trains WHERE id=?");
        $st->execute([$id]);
        return $st->fetch();
    }
    public function createTrain(string $name, string $origin, string $dest, float $price): bool {
        $st = db()->prepare("INSERT INTO trains (train_name,origin,destination,price) VALUES (?,?,?,?)");
        return $st->execute([$name,$origin,$dest,$price]);
    }
    public function updateTrain(int $id, string $name, string $origin, string $dest, float $price): bool {
        $st = db()->prepare("UPDATE trains SET train_name=?,origin=?,destination=?,price=? WHERE id=?");
        return $st->execute([$name,$origin,$dest,$price,$id]);
    }
    public function deleteTrain(int $id): bool {
        $st = db()->prepare("DELETE FROM trains WHERE id=?");
        return $st->execute([$id]);
    }
    public function countTrains(): int {
        return (int)db()->query("SELECT COUNT(*) FROM trains")->fetchColumn();
    }
    public function getAllOrigins(): array {
        return db()->query("SELECT DISTINCT origin FROM trains ORDER BY origin")->fetchAll(PDO::FETCH_COLUMN);
    }
    public function getAllDestinations(): array {
        return db()->query("SELECT DISTINCT destination FROM trains ORDER BY destination")->fetchAll(PDO::FETCH_COLUMN);
    }

    // ── SCHEDULES ─────────────────────────────────────────────
    public function getAllSchedules(): array {
        $sql = "SELECT s.*, t.train_name, t.origin, t.destination, t.price
                FROM schedules s JOIN trains t ON s.train_id=t.id ORDER BY s.departure_time DESC";
        return db()->query($sql)->fetchAll();
    }
    public function getScheduleById(int $id): array|false {
        $sql = "SELECT s.*, t.train_name, t.origin, t.destination, t.price
                FROM schedules s JOIN trains t ON s.train_id=t.id WHERE s.id=? LIMIT 1";
        $st = db()->prepare($sql);
        $st->execute([$id]);
        return $st->fetch();
    }
    public function searchSchedules(string $origin, string $dest, string $date): array {
        $sql = "SELECT s.*, t.train_name, t.origin, t.destination, t.price
                FROM schedules s JOIN trains t ON s.train_id=t.id
                WHERE t.origin=? AND t.destination=? AND DATE(s.departure_time)=?
                AND s.available_seats > 0
                ORDER BY s.departure_time ASC";
        $st = db()->prepare($sql);
        $st->execute([$origin,$dest,$date]);
        return $st->fetchAll();
    }
    public function createSchedule(int $trainId, string $dep, string $arr, int $seats): bool {
        $st = db()->prepare("INSERT INTO schedules (train_id,departure_time,arrival_time,available_seats) VALUES (?,?,?,?)");
        return $st->execute([$trainId,$dep,$arr,$seats]);
    }
    public function updateSchedule(int $id, int $trainId, string $dep, string $arr, int $seats): bool {
        $st = db()->prepare("UPDATE schedules SET train_id=?,departure_time=?,arrival_time=?,available_seats=? WHERE id=?");
        return $st->execute([$trainId,$dep,$arr,$seats,$id]);
    }
    public function deleteSchedule(int $id): bool {
        $st = db()->prepare("DELETE FROM schedules WHERE id=?");
        return $st->execute([$id]);
    }
    public function countSchedules(): int {
        return (int)db()->query("SELECT COUNT(*) FROM schedules")->fetchColumn();
    }

    // ── BOOKINGS ──────────────────────────────────────────────
    public function isSeatTaken(int $scheduleId, string $seat): bool {
        $st = db()->prepare("SELECT COUNT(*) FROM bookings WHERE schedule_id=? AND seat_number=? AND payment_status != 'Cancelled'");
        $st->execute([$scheduleId,$seat]);
        return (int)$st->fetchColumn() > 0;
    }
    public function getBookedSeats(int $scheduleId): array {
        $st = db()->prepare("SELECT seat_number FROM bookings WHERE schedule_id=? AND payment_status != 'Cancelled'");
        $st->execute([$scheduleId]);
        return $st->fetchAll(PDO::FETCH_COLUMN);
    }
    public function createBooking(int $userId, int $scheduleId, string $seat, string $code): int {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            // Double-check seat
            if ($this->isSeatTaken($scheduleId, $seat)) {
                $pdo->rollBack();
                return 0;
            }
            $st = $pdo->prepare("INSERT INTO bookings (user_id,schedule_id,seat_number,booking_code,payment_status) VALUES (?,?,?,?,'Pending')");
            $st->execute([$userId,$scheduleId,$seat,$code]);
            $bookingId = (int)$pdo->lastInsertId();
            // Decrease available seats
            $pdo->prepare("UPDATE schedules SET available_seats = available_seats - 1 WHERE id=? AND available_seats > 0")->execute([$scheduleId]);
            $pdo->commit();
            return $bookingId;
        } catch (Exception $e) {
            $pdo->rollBack();
            return 0;
        }
    }
    public function getBookingById(int $id): array|false {
        $sql = "SELECT b.*, u.name as user_name, u.email as user_email,
                       s.departure_time, s.arrival_time,
                       t.train_name, t.origin, t.destination, t.price
                FROM bookings b
                JOIN users u ON b.user_id=u.id
                JOIN schedules s ON b.schedule_id=s.id
                JOIN trains t ON s.train_id=t.id
                WHERE b.id=? LIMIT 1";
        $st = db()->prepare($sql);
        $st->execute([$id]);
        return $st->fetch();
    }
    public function getBookingByCode(string $code): array|false {
        $sql = "SELECT b.*, u.name as user_name, u.email as user_email,
                       s.departure_time, s.arrival_time,
                       t.train_name, t.origin, t.destination, t.price
                FROM bookings b
                JOIN users u ON b.user_id=u.id
                JOIN schedules s ON b.schedule_id=s.id
                JOIN trains t ON s.train_id=t.id
                WHERE b.booking_code=? LIMIT 1";
        $st = db()->prepare($sql);
        $st->execute([$code]);
        return $st->fetch();
    }
    public function getUserBookings(int $userId): array {
        $sql = "SELECT b.*, t.train_name, t.origin, t.destination, t.price,
                       s.departure_time, s.arrival_time
                FROM bookings b
                JOIN schedules s ON b.schedule_id=s.id
                JOIN trains t ON s.train_id=t.id
                WHERE b.user_id=? ORDER BY b.created_at DESC";
        $st = db()->prepare($sql);
        $st->execute([$userId]);
        return $st->fetchAll();
    }
    public function getAllBookings(): array {
        $sql = "SELECT b.*, u.name as user_name, u.email as user_email,
                       t.train_name, t.origin, t.destination, t.price,
                       s.departure_time, s.arrival_time
                FROM bookings b
                JOIN users u ON b.user_id=u.id
                JOIN schedules s ON b.schedule_id=s.id
                JOIN trains t ON s.train_id=t.id
                ORDER BY b.created_at DESC";
        return db()->query($sql)->fetchAll();
    }
    public function updateBookingStatus(int $id, string $status): bool {
        $allowed = ['Pending','Paid','Cancelled'];
        if (!in_array($status, $allowed)) return false;
        // If cancelling, restore seat
        if ($status === 'Cancelled') {
            $bk = $this->getBookingById($id);
            if ($bk && $bk['payment_status'] !== 'Cancelled') {
                db()->prepare("UPDATE schedules SET available_seats=available_seats+1 WHERE id=?")->execute([$bk['schedule_id']]);
            }
        }
        $st = db()->prepare("UPDATE bookings SET payment_status=? WHERE id=?");
        return $st->execute([$status,$id]);
    }
    public function payBooking(int $id): bool {
        $st = db()->prepare("UPDATE bookings SET payment_status='Paid' WHERE id=? AND payment_status='Pending'");
        return $st->execute([$id]);
    }
    public function countBookings(): int {
        return (int)db()->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
    }
    public function totalRevenue(): float {
        $sql = "SELECT COALESCE(SUM(t.price),0) FROM bookings b JOIN schedules s ON b.schedule_id=s.id JOIN trains t ON s.train_id=t.id WHERE b.payment_status='Paid'";
        return (float)db()->query($sql)->fetchColumn();
    }
    public function recentBookings(int $limit=5): array {
        $sql = "SELECT b.*, u.name as user_name, t.train_name, t.origin, t.destination, s.departure_time
                FROM bookings b JOIN users u ON b.user_id=u.id JOIN schedules s ON b.schedule_id=s.id JOIN trains t ON s.train_id=t.id
                ORDER BY b.created_at DESC LIMIT ?";
        $st = db()->prepare($sql);
        $st->execute([$limit]);
        return $st->fetchAll();
    }
    public function bookingStats(): array {
        $res = db()->query("SELECT payment_status, COUNT(*) as cnt FROM bookings GROUP BY payment_status")->fetchAll();
        $stats = ['Pending'=>0,'Paid'=>0,'Cancelled'=>0];
        foreach ($res as $r) $stats[$r['payment_status']] = (int)$r['cnt'];
        return $stats;
    }
}
