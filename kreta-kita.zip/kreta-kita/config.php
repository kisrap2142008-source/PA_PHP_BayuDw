<?php
// ============================================================
// KRETA KITA — config.php
// ============================================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'kreta_kita');
define('DB_USER', 'root');
define('DB_PASS', '');
define('BASE_URL', 'http://localhost/kreta-kita');
define('APP_NAME', 'Kreta Kita');

if (session_status() === PHP_SESSION_NONE) session_start();

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die('<div style="font-family:monospace;padding:20px;background:#fee;border:1px solid red">DB Error: '.$e->getMessage().'</div>');
        }
    }
    return $pdo;
}

function isLoggedIn(): bool { return !empty($_SESSION['user_id']); }
function isAdmin(): bool    { return isLoggedIn() && ($_SESSION['role'] ?? '') === 'admin'; }

function requireLogin(): void {
    if (!isLoggedIn()) { flash('error','Silakan login terlebih dahulu.'); redirect('login'); }
}
function requireAdmin(): void {
    requireLogin();
    if (!isAdmin()) { flash('error','Akses ditolak.'); redirect('dashboard'); }
}

function redirect(string $page, array $params = []): void {
    $url = 'index.php?page='.$page;
    foreach ($params as $k=>$v) $url .= '&'.$k.'='.urlencode((string)$v);
    header('Location: '.$url); exit;
}

function flash(string $key, ?string $msg = null): ?string {
    if ($msg !== null) { $_SESSION['flash'][$key] = $msg; return null; }
    $val = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $val;
}

function generateBookingCode(): string {
    return 'KK-'.date('Y').'-'.strtoupper(substr(bin2hex(random_bytes(3)),0,5));
}

function e(mixed $str): string { return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8'); }
function rupiah(mixed $amount): string { return 'Rp '.number_format((float)$amount,0,',','.'); }
function fmtDate(string $dt, string $fmt='d M Y'): string { return date($fmt, strtotime($dt)); }
function fmtTime(string $dt): string { return date('H:i', strtotime($dt)); }

function csrfToken(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function verifyCsrf(): void {
    if (!hash_equals($_SESSION['csrf_token']??'', $_POST['csrf_token']??'')) {
        flash('error','Token keamanan tidak valid.'); header('Location: '.$_SERVER['HTTP_REFERER']); exit;
    }
}
