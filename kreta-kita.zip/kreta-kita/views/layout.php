<?php
// ============================================================
// KRETA KITA — views/layout.php
// Master layout + all view partials + embedded CSS
// ============================================================

function renderLayout(string $view, array $data = []): void {
    extract($data);
    $isAuth       = isLoggedIn();
    $isAdminUser  = isAdmin();
    $userName     = $_SESSION['name'] ?? '';
    $userRole     = $_SESSION['role'] ?? '';
    $currentPage  = $_GET['page'] ?? '';
    $flashSuccess = flash('success');
    $flashError   = flash('error');

    // Pages that use full-screen auth layout (no sidebar)
    $authPages = ['login','register'];
    $useAuth   = in_array($view, $authPages);
    ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= APP_NAME ?> — <?= ucwords(str_replace('_',' ',$view)) ?></title>
<style>
/* ============================================================
   KRETA KITA — Complete Embedded CSS
   ============================================================ */
:root {
  --primary:   #1a56db;
  --primary-d: #1346c5;
  --primary-l: #ebf0ff;
  --accent:    #0ea5e9;
  --success:   #059669;
  --warning:   #d97706;
  --danger:    #dc2626;
  --dark:      #0f172a;
  --dark2:     #1e293b;
  --dark3:     #334155;
  --muted:     #64748b;
  --border:    #e2e8f0;
  --bg:        #f1f5f9;
  --white:     #ffffff;
  --sidebar-w: 260px;
  --radius:    12px;
  --shadow:    0 1px 3px rgba(0,0,0,.08), 0 4px 16px rgba(0,0,0,.06);
  --shadow-lg: 0 10px 40px rgba(0,0,0,.15);
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { background: var(--bg); color: var(--dark); min-height: 100vh; font-size: 14px; line-height: 1.6; }
a { color: var(--primary); text-decoration: none; }
a:hover { text-decoration: underline; }
img { max-width: 100%; }

/* ── Typography ── */
h1 { font-size: 1.75rem; font-weight: 700; color: var(--dark); }
h2 { font-size: 1.35rem; font-weight: 700; }
h3 { font-size: 1.1rem; font-weight: 600; }
.text-muted { color: var(--muted); }
.text-sm { font-size: .8125rem; }
.text-xs { font-size: .75rem; }
.text-center { text-align: center; }
.fw-bold { font-weight: 700; }
.text-success { color: var(--success); }
.text-danger  { color: var(--danger); }
.text-warning { color: var(--warning); }
.text-primary { color: var(--primary); }

/* ── Auth Layout ── */
.auth-wrapper {
  min-height: 100vh; display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, var(--dark) 0%, var(--dark2) 50%, #1a3a6b 100%);
  padding: 1rem;
}
.auth-card {
  background: var(--white); border-radius: 20px; box-shadow: var(--shadow-lg);
  width: 100%; max-width: 440px; overflow: hidden;
}
.auth-header {
  background: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
  color: var(--white); padding: 2rem; text-align: center;
}
.auth-header .logo-icon {
  font-size: 2.5rem; margin-bottom: .5rem; display: block;
}
.auth-header h1 { color: var(--white); font-size: 1.75rem; }
.auth-header p { opacity: .85; font-size: .9rem; margin-top: .25rem; }
.auth-body { padding: 2rem; }

/* ── App Layout ── */
.app-wrapper { display: flex; min-height: 100vh; }
.sidebar {
  width: var(--sidebar-w); background: var(--dark); color: var(--white);
  display: flex; flex-direction: column; flex-shrink: 0; position: fixed;
  top: 0; left: 0; height: 100vh; overflow-y: auto; z-index: 100;
}
.sidebar-brand {
  padding: 1.5rem 1.25rem; border-bottom: 1px solid rgba(255,255,255,.08);
  display: flex; align-items: center; gap: .75rem;
}
.brand-icon { font-size: 1.75rem; }
.brand-text h2 { color: var(--white); font-size: 1.1rem; }
.brand-text span { color: rgba(255,255,255,.5); font-size: .7rem; text-transform: uppercase; letter-spacing: 1px; }
.sidebar-user {
  padding: 1rem 1.25rem; border-bottom: 1px solid rgba(255,255,255,.08);
  display: flex; align-items: center; gap: .75rem;
}
.user-avatar {
  width: 36px; height: 36px; border-radius: 50%;
  background: linear-gradient(135deg, var(--primary), var(--accent));
  display: flex; align-items: center; justify-content: center;
  font-weight: 700; font-size: .85rem; flex-shrink: 0;
}
.user-info p { font-size: .85rem; font-weight: 600; color: var(--white); }
.user-info span { font-size: .7rem; color: rgba(255,255,255,.5); text-transform: capitalize; }
.sidebar-nav { flex: 1; padding: 1rem 0; }
.nav-section { padding: .5rem 1.25rem .25rem; font-size: .65rem; font-weight: 700;
  text-transform: uppercase; letter-spacing: 1.5px; color: rgba(255,255,255,.3); }
.nav-item a {
  display: flex; align-items: center; gap: .75rem; padding: .625rem 1.25rem;
  color: rgba(255,255,255,.7); transition: all .2s; font-size: .875rem; border-radius: 0;
}
.nav-item a:hover { color: var(--white); background: rgba(255,255,255,.07); text-decoration: none; }
.nav-item a.active { color: var(--white); background: var(--primary); }
.nav-item a .nav-icon { font-size: 1rem; width: 20px; text-align: center; }
.sidebar-footer { padding: 1rem 1.25rem; border-top: 1px solid rgba(255,255,255,.08); }
.sidebar-footer a { display: flex; align-items: center; gap: .75rem; color: rgba(255,255,255,.6);
  font-size: .875rem; transition: color .2s; }
.sidebar-footer a:hover { color: var(--danger); text-decoration: none; }

.main-area { margin-left: var(--sidebar-w); flex: 1; display: flex; flex-direction: column; min-height: 100vh; }
.topbar {
  background: var(--white); border-bottom: 1px solid var(--border);
  padding: .875rem 1.5rem; display: flex; align-items: center; justify-content: space-between;
  position: sticky; top: 0; z-index: 50;
}
.topbar-left h1 { font-size: 1.2rem; }
.topbar-left p { font-size: .8rem; color: var(--muted); }
.topbar-right { display: flex; align-items: center; gap: .75rem; }
.badge-pill {
  display: inline-flex; align-items: center; padding: .2rem .75rem;
  border-radius: 50px; font-size: .7rem; font-weight: 600; text-transform: uppercase; letter-spacing: .5px;
}
.badge-admin  { background: #fef3c7; color: #92400e; }
.badge-user   { background: #dbeafe; color: #1e40af; }
.badge-paid      { background: #d1fae5; color: #065f46; }
.badge-pending   { background: #fef3c7; color: #92400e; }
.badge-cancelled { background: #fee2e2; color: #991b1b; }
.main-content { padding: 1.5rem; flex: 1; }

/* ── Cards ── */
.card {
  background: var(--white); border-radius: var(--radius); box-shadow: var(--shadow);
  border: 1px solid var(--border); overflow: hidden;
}
.card-header {
  padding: 1rem 1.25rem; border-bottom: 1px solid var(--border);
  display: flex; align-items: center; justify-content: space-between;
}
.card-header h3 { font-size: 1rem; }
.card-body { padding: 1.25rem; }

/* ── Stat Cards ── */
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px,1fr)); gap: 1rem; margin-bottom: 1.5rem; }
.stat-card {
  background: var(--white); border-radius: var(--radius); box-shadow: var(--shadow);
  border: 1px solid var(--border); padding: 1.25rem;
  display: flex; align-items: center; gap: 1rem; transition: transform .2s;
}
.stat-card:hover { transform: translateY(-2px); }
.stat-icon {
  width: 52px; height: 52px; border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.5rem; flex-shrink: 0;
}
.si-blue   { background: #ebf0ff; }
.si-green  { background: #d1fae5; }
.si-orange { background: #fef3c7; }
.si-purple { background: #ede9fe; }
.stat-info p { font-size: .8rem; color: var(--muted); margin-bottom: .15rem; }
.stat-info h2 { font-size: 1.5rem; font-weight: 800; }

/* ── Forms ── */
.form-group { margin-bottom: 1.25rem; }
.form-label { display: block; font-size: .875rem; font-weight: 600; margin-bottom: .4rem; color: var(--dark2); }
.form-label span { color: var(--danger); }
.form-control {
  width: 100%; padding: .625rem .875rem; border: 1.5px solid var(--border); border-radius: 8px;
  font-size: .9rem; font-family: inherit; transition: border-color .2s, box-shadow .2s;
  background: var(--white); color: var(--dark);
}
.form-control:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(26,86,219,.12); }
.form-control::placeholder { color: #a0aec0; }
select.form-control { cursor: pointer; }
textarea.form-control { resize: vertical; min-height: 100px; }
.form-text { font-size: .78rem; color: var(--muted); margin-top: .3rem; }
.form-row { display: grid; gap: 1rem; }
.form-row.col-2 { grid-template-columns: 1fr 1fr; }
.form-row.col-3 { grid-template-columns: 1fr 1fr 1fr; }

/* ── Buttons ── */
.btn {
  display: inline-flex; align-items: center; gap: .4rem; padding: .6rem 1.25rem;
  border-radius: 8px; font-size: .875rem; font-weight: 600; cursor: pointer;
  border: none; transition: all .2s; white-space: nowrap; font-family: inherit;
  line-height: 1;
}
.btn:hover { transform: translateY(-1px); text-decoration: none; }
.btn-primary  { background: var(--primary); color: var(--white); box-shadow: 0 4px 12px rgba(26,86,219,.3); }
.btn-primary:hover  { background: var(--primary-d); color: var(--white); }
.btn-success  { background: var(--success); color: var(--white); box-shadow: 0 4px 12px rgba(5,150,105,.3); }
.btn-success:hover  { background: #047857; color: var(--white); }
.btn-danger   { background: var(--danger); color: var(--white); box-shadow: 0 4px 12px rgba(220,38,38,.3); }
.btn-danger:hover   { background: #b91c1c; color: var(--white); }
.btn-warning  { background: var(--warning); color: var(--white); }
.btn-warning:hover  { background: #b45309; color: var(--white); }
.btn-outline  { background: transparent; color: var(--primary); border: 1.5px solid var(--primary); box-shadow: none; }
.btn-outline:hover  { background: var(--primary-l); color: var(--primary); }
.btn-secondary { background: var(--border); color: var(--dark2); box-shadow: none; }
.btn-secondary:hover { background: #cbd5e1; color: var(--dark); }
.btn-sm  { padding: .35rem .8rem; font-size: .8rem; border-radius: 6px; }
.btn-lg  { padding: .875rem 2rem; font-size: 1rem; border-radius: 10px; }
.btn-block { width: 100%; justify-content: center; }

/* ── Tables ── */
.table-wrapper { overflow-x: auto; border-radius: var(--radius); }
table { width: 100%; border-collapse: collapse; }
thead tr { background: var(--bg); }
th { padding: .75rem 1rem; font-size: .75rem; font-weight: 700; text-transform: uppercase;
  letter-spacing: .5px; color: var(--muted); text-align: left; white-space: nowrap; }
td { padding: .875rem 1rem; border-bottom: 1px solid var(--border); font-size: .875rem; vertical-align: middle; }
tbody tr:last-child td { border-bottom: none; }
tbody tr:hover { background: #f8fafc; }

/* ── Alerts ── */
.alert {
  padding: .875rem 1.1rem; border-radius: 10px; margin-bottom: 1.25rem;
  display: flex; align-items: flex-start; gap: .6rem; font-size: .875rem;
}
.alert-success { background: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
.alert-error   { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
.alert-info    { background: #dbeafe; color: #1e40af; border: 1px solid #bfdbfe; }
.alert-icon { font-size: 1rem; flex-shrink: 0; margin-top: .1rem; }

/* ── Search Form ── */
.search-hero {
  background: linear-gradient(135deg, var(--dark) 0%, var(--dark2) 60%, #1a3a6b 100%);
  border-radius: var(--radius); padding: 2rem; margin-bottom: 1.5rem; color: var(--white);
}
.search-hero h2 { color: var(--white); font-size: 1.5rem; margin-bottom: .4rem; }
.search-hero p { color: rgba(255,255,255,.7); margin-bottom: 1.5rem; }
.search-grid {
  display: grid; grid-template-columns: 1fr 1fr 1fr auto; gap: 1rem; align-items: end;
}
.search-grid .form-label { color: rgba(255,255,255,.8); }
.search-grid .form-control { background: rgba(255,255,255,.1); border-color: rgba(255,255,255,.2); color: var(--white); }
.search-grid .form-control::placeholder { color: rgba(255,255,255,.4); }
.search-grid .form-control:focus { background: rgba(255,255,255,.15); border-color: rgba(255,255,255,.5); }
.search-grid select.form-control option { background: var(--dark2); color: var(--white); }

/* ── Schedule Cards ── */
.schedule-list { display: flex; flex-direction: column; gap: 1rem; }
.schedule-card {
  background: var(--white); border-radius: var(--radius); box-shadow: var(--shadow);
  border: 1px solid var(--border); padding: 1.25rem;
  display: flex; align-items: center; gap: 1.25rem; transition: all .2s;
}
.schedule-card:hover { border-color: var(--primary); box-shadow: 0 4px 20px rgba(26,86,219,.12); transform: translateY(-1px); }
.train-logo {
  width: 52px; height: 52px; border-radius: 12px;
  background: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
  display: flex; align-items: center; justify-content: center;
  font-size: 1.5rem; flex-shrink: 0; color: var(--white);
}
.schedule-route { flex: 1; }
.route-line { display: flex; align-items: center; gap: .75rem; margin-bottom: .4rem; }
.city-name { font-weight: 700; font-size: 1.1rem; }
.route-arrow { color: var(--muted); font-size: 1rem; }
.route-meta { font-size: .8rem; color: var(--muted); display: flex; gap: 1rem; }
.schedule-time { text-align: center; }
.time-display { font-size: 1.3rem; font-weight: 800; }
.time-label   { font-size: .7rem; color: var(--muted); text-transform: uppercase; letter-spacing: .5px; }
.schedule-duration { text-align: center; padding: 0 1rem; border-left: 1px solid var(--border); border-right: 1px solid var(--border); }
.schedule-price { text-align: center; }
.price-amount { font-size: 1.1rem; font-weight: 800; color: var(--primary); }
.price-label  { font-size: .7rem; color: var(--muted); }

/* ── Seat Selection ── */
.seat-map { padding: 1rem; }
.seat-legend { display: flex; gap: 1.5rem; margin-bottom: 1.5rem; flex-wrap: wrap; }
.legend-item { display: flex; align-items: center; gap: .5rem; font-size: .8rem; color: var(--muted); }
.legend-box { width: 22px; height: 22px; border-radius: 4px; }
.legend-available { background: #dbeafe; border: 1.5px solid #93c5fd; }
.legend-booked    { background: #fee2e2; border: 1.5px solid #fca5a5; }
.legend-selected  { background: var(--primary); border: 1.5px solid var(--primary); }
.seat-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: .5rem; max-width: 280px; }
.seat-btn {
  width: 50px; height: 50px; border-radius: 8px; border: 1.5px solid #93c5fd;
  background: #dbeafe; cursor: pointer; font-size: .8rem; font-weight: 700;
  color: var(--primary); transition: all .15s; display: flex; align-items: center; justify-content: center;
}
.seat-btn:hover:not(.booked) { background: var(--primary); color: var(--white); border-color: var(--primary); }
.seat-btn.selected { background: var(--primary); color: var(--white); border-color: var(--primary); }
.seat-btn.booked   { background: #fee2e2; border-color: #fca5a5; color: #fca5a5; cursor: not-allowed; }
.seat-aisle { grid-column: 3; background: transparent; border: none; cursor: default; }
.seat-aisle:hover { background: transparent; color: transparent; }

/* ── Ticket ── */
.ticket-wrapper {
  max-width: 700px; margin: 0 auto;
  background: var(--white); border-radius: 20px; overflow: hidden; box-shadow: var(--shadow-lg);
}
.ticket-top {
  background: linear-gradient(135deg, var(--dark) 0%, var(--dark2) 100%);
  color: var(--white); padding: 2rem;
}
.ticket-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; }
.ticket-brand { display: flex; align-items: center; gap: .5rem; }
.ticket-brand h2 { color: var(--white); }
.ticket-status .badge-pill { padding: .4rem 1rem; }
.ticket-route { display: flex; align-items: center; justify-content: space-between; gap: 1rem; }
.ticket-city { text-align: center; }
.ticket-city .city-code { font-size: 3rem; font-weight: 900; letter-spacing: -1px; }
.ticket-city .city-full { font-size: .85rem; opacity: .7; }
.ticket-divider { flex: 1; position: relative; }
.ticket-divider::before {
  content: ''; position: absolute; top: 50%; left: 0; right: 0;
  height: 1px; background: repeating-linear-gradient(90deg, rgba(255,255,255,.3) 0, rgba(255,255,255,.3) 6px, transparent 6px, transparent 12px);
}
.ticket-divider .plane-icon { position: relative; text-align: center; font-size: 1.5rem; }
.ticket-body { padding: 1.5rem 2rem; }
.ticket-details { display: grid; grid-template-columns: repeat(3,1fr); gap: 1rem; margin-bottom: 1.5rem; }
.ticket-detail-item p { font-size: .75rem; color: var(--muted); text-transform: uppercase; letter-spacing: .5px; margin-bottom: .2rem; }
.ticket-detail-item h4 { font-size: .95rem; font-weight: 700; }
.ticket-cut {
  position: relative; margin: 0 -2rem;
  border-top: 2px dashed var(--border);
}
.ticket-cut::before, .ticket-cut::after {
  content: ''; position: absolute; top: -12px; width: 22px; height: 22px;
  background: var(--bg); border-radius: 50%;
}
.ticket-cut::before { left: -11px; }
.ticket-cut::after  { right: -11px; }
.ticket-barcode { padding: 1.25rem 0 .5rem; text-align: center; }
.barcode-lines { display: flex; gap: 2px; height: 50px; justify-content: center; align-items: flex-end; margin-bottom: .5rem; }
.barcode-lines span { display: inline-block; width: 2px; background: var(--dark); }
.booking-code-display { font-size: 1.1rem; font-weight: 800; letter-spacing: 4px; color: var(--dark); font-family: monospace; }

/* ── Pagination / Empty State ── */
.empty-state { text-align: center; padding: 3rem 1rem; }
.empty-icon { font-size: 4rem; margin-bottom: 1rem; opacity: .4; }
.empty-state h3 { color: var(--dark2); margin-bottom: .5rem; }
.empty-state p { color: var(--muted); margin-bottom: 1.5rem; }

/* ── Payment ── */
.payment-card { max-width: 560px; margin: 0 auto; }
.payment-summary {
  background: var(--primary-l); border: 1.5px solid #bfdbfe; border-radius: 12px;
  padding: 1.25rem; margin-bottom: 1.5rem;
}
.payment-row { display: flex; justify-content: space-between; align-items: center;
  padding: .4rem 0; border-bottom: 1px solid rgba(26,86,219,.1); font-size: .9rem; }
.payment-row:last-child { border-bottom: none; padding-top: .75rem; margin-top: .25rem; }
.payment-row.total { font-weight: 800; font-size: 1.1rem; color: var(--primary); }
.payment-methods { display: grid; grid-template-columns: 1fr 1fr; gap: .75rem; margin-bottom: 1.5rem; }
.payment-method-btn {
  border: 2px solid var(--border); border-radius: 10px; padding: 1rem; cursor: pointer;
  display: flex; align-items: center; gap: .75rem; transition: all .2s; background: var(--white);
}
.payment-method-btn:hover { border-color: var(--primary); background: var(--primary-l); }
.payment-method-btn.selected { border-color: var(--primary); background: var(--primary-l); }
.pm-icon { font-size: 1.5rem; }
.pm-name { font-size: .85rem; font-weight: 600; }
.pm-desc { font-size: .7rem; color: var(--muted); }

/* ── Misc Utilities ── */
.flex { display: flex; }
.flex-center { display: flex; align-items: center; }
.flex-between { display: flex; align-items: center; justify-content: space-between; }
.gap-1 { gap: .25rem; }
.gap-2 { gap: .5rem; }
.gap-3 { gap: .75rem; }
.gap-4 { gap: 1rem; }
.mt-1 { margin-top: .25rem; }
.mt-2 { margin-top: .5rem; }
.mt-3 { margin-top: .75rem; }
.mt-4 { margin-top: 1rem; }
.mb-4 { margin-bottom: 1rem; }
.mb-3 { margin-bottom: .75rem; }
.p-4 { padding: 1rem; }
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
.grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1.5rem; }
.divider { height: 1px; background: var(--border); margin: 1.25rem 0; }

/* ── No-print ── */
@media print {
  .no-print, .sidebar, .topbar, .topbar-right { display: none !important; }
  .main-area { margin-left: 0 !important; }
  .ticket-wrapper { box-shadow: none; }
}
@media (max-width: 768px) {
  .sidebar { transform: translateX(-100%); }
  .main-area { margin-left: 0; }
  .search-grid { grid-template-columns: 1fr; }
  .form-row.col-2, .form-row.col-3 { grid-template-columns: 1fr; }
  .schedule-card { flex-direction: column; align-items: flex-start; }
  .ticket-details { grid-template-columns: 1fr 1fr; }
  .ticket-city .city-code { font-size: 2rem; }
  .stats-grid { grid-template-columns: 1fr 1fr; }
  .grid-2, .grid-3 { grid-template-columns: 1fr; }
}
</style>
</head>
<body>
<?php if ($useAuth): ?>
<!-- ========= AUTH LAYOUT ========= -->
<div class="auth-wrapper">
  <div class="auth-card">
    <div class="auth-header">
      <span class="logo-icon">🚂</span>
      <h1><?= APP_NAME ?></h1>
      <p>Sistem Pemesanan Tiket Kereta</p>
    </div>
    <div class="auth-body">
      <?php renderFlash($flashSuccess, $flashError); ?>
      <?php if ($view === 'login'): ?>
        <?php renderLoginForm(); ?>
      <?php elseif ($view === 'register'): ?>
        <?php renderRegisterForm(); ?>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php else: ?>
<!-- ========= APP LAYOUT ========= -->
<div class="app-wrapper">
  <!-- Sidebar -->
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="brand-icon">🚂</div>
      <div class="brand-text">
        <h2><?= APP_NAME ?></h2>
        <span>Ticket Booking System</span>
      </div>
    </div>
    <div class="sidebar-user">
      <div class="user-avatar"><?= strtoupper(substr($userName,0,1)) ?></div>
      <div class="user-info">
        <p><?= e($userName) ?></p>
        <span>&#x2022; <?= $userRole ?></span>
      </div>
    </div>
    <nav class="sidebar-nav">
      <?php if ($isAdminUser): ?>
      <div class="nav-section">Overview</div>
      <div class="nav-item"><a href="index.php?page=admin_dashboard" class="<?= $currentPage==='admin_dashboard'?'active':'' ?>">
        <span class="nav-icon">📊</span> Dashboard
      </a></div>
      <div class="nav-section">Master Data</div>
      <div class="nav-item"><a href="index.php?page=admin_trains" class="<?= str_contains($currentPage,'admin_train')?'active':'' ?>">
        <span class="nav-icon">🚃</span> Manajemen Kereta
      </a></div>
      <div class="nav-item"><a href="index.php?page=admin_schedules" class="<?= str_contains($currentPage,'admin_schedule')?'active':'' ?>">
        <span class="nav-icon">📅</span> Jadwal Keberangkatan
      </a></div>
      <div class="nav-section">Transaksi</div>
      <div class="nav-item"><a href="index.php?page=admin_bookings" class="<?= $currentPage==='admin_bookings'?'active':'' ?>">
        <span class="nav-icon">🎫</span> Semua Pemesanan
      </a></div>
      <?php else: ?>
      <div class="nav-section">Menu</div>
      <div class="nav-item"><a href="index.php?page=dashboard" class="<?= $currentPage==='dashboard'?'active':'' ?>">
        <span class="nav-icon">🏠</span> Beranda
      </a></div>
      <div class="nav-item"><a href="index.php?page=search" class="<?= $currentPage==='search'||$currentPage==='schedule_detail'?'active':'' ?>">
        <span class="nav-icon">🔍</span> Cari Jadwal
      </a></div>
      <div class="nav-item"><a href="index.php?page=my_bookings" class="<?= $currentPage==='my_bookings'?'active':'' ?>">
        <span class="nav-icon">🎫</span> Pemesanan Saya
      </a></div>
      <?php endif; ?>
    </nav>
    <div class="sidebar-footer">
      <a href="index.php?page=logout" onclick="return confirm('Yakin ingin logout?')">
        <span class="nav-icon">🚪</span> Logout
      </a>
    </div>
  </aside>

  <!-- Main Area -->
  <div class="main-area">
    <header class="topbar">
      <div class="topbar-left">
        <?php
        $titles = [
          'dashboard'=>['Beranda','Selamat datang di Kreta Kita'],
          'search'=>['Cari Jadwal','Temukan kereta tujuanmu'],
          'schedule_detail'=>['Detail Jadwal','Pilih kursi dan pesan tiket'],
          'payment'=>['Konfirmasi Pembayaran','Selesaikan pemesananmu'],
          'ticket'=>['Tiket Digital','Tiket perjalananmu'],
          'my_bookings'=>['Pemesanan Saya','Riwayat semua pemesanan'],
          'admin_dashboard'=>['Dashboard Admin','Ringkasan sistem Kreta Kita'],
          'admin_trains'=>['Manajemen Kereta','CRUD data armada kereta'],
          'admin_train_form'=>['Form Kereta','Tambah / Edit data kereta'],
          'admin_schedules'=>['Jadwal Keberangkatan','Kelola jadwal dan kursi'],
          'admin_schedule_form'=>['Form Jadwal','Tambah / Edit jadwal'],
          'admin_bookings'=>['Semua Pemesanan','Manajemen tiket & pembayaran'],
        ];
        $title = $titles[$currentPage] ?? [ucwords(str_replace('_',' ',$currentPage)),''];
        ?>
        <h1><?= $title[0] ?></h1>
        <?php if ($title[1]): ?><p><?= $title[1] ?></p><?php endif; ?>
      </div>
      <div class="topbar-right">
        <span class="badge-pill <?= $isAdminUser ? 'badge-admin' : 'badge-user' ?>">
          <?= $isAdminUser ? '⚙️ Admin' : '👤 User' ?>
        </span>
      </div>
    </header>
    <div class="main-content">
      <?php renderFlash($flashSuccess, $flashError); ?>
      <?php
      // Render the correct view
      switch ($view) {
          case 'user_dashboard':     renderUserDashboard($data); break;
          case 'search':             renderSearch($data); break;
          case 'schedule_detail':    renderScheduleDetail($data); break;
          case 'payment':            renderPayment($data); break;
          case 'ticket':             renderTicket($data); break;
          case 'my_bookings':        renderMyBookings($data); break;
          case 'admin_dashboard':    renderAdminDashboard($data); break;
          case 'admin_trains':       renderAdminTrains($data); break;
          case 'admin_train_form':   renderAdminTrainForm($data); break;
          case 'admin_schedules':    renderAdminSchedules($data); break;
          case 'admin_schedule_form':renderAdminScheduleForm($data); break;
          case 'admin_bookings':     renderAdminBookings($data); break;
          default: echo '<p>View not found: ' . e($view) . '</p>';
      }
      ?>
    </div>
  </div>
</div>
<?php endif; ?>
</body>
</html>
<?php
}

// ============================================================
// HELPER: Flash Messages
// ============================================================
function renderFlash(?string $success, ?string $error): void {
    if ($success): ?>
    <div class="alert alert-success"><span class="alert-icon">✅</span><span><?= e($success) ?></span></div>
    <?php endif;
    if ($error): ?>
    <div class="alert alert-error"><span class="alert-icon">❌</span><span><?= e($error) ?></span></div>
    <?php endif;
}

// ============================================================
// VIEW: Login
// ============================================================
function renderLoginForm(): void { ?>
<h2 class="text-center" style="margin-bottom:.25rem">Selamat Datang</h2>
<p class="text-center text-muted text-sm" style="margin-bottom:1.5rem">Masuk ke akun Kreta Kita Anda</p>
<form method="POST" action="index.php?page=login">
  <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
  <div class="form-group">
    <label class="form-label">Email <span>*</span></label>
    <input type="email" name="email" class="form-control" placeholder="contoh@email.com" required value="<?= e($_POST['email']??'') ?>">
  </div>
  <div class="form-group">
    <label class="form-label">Password <span>*</span></label>
    <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
  </div>
  <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-bottom:1rem">🔐 Masuk</button>
  <p class="text-center text-sm text-muted">
    Belum punya akun? <a href="index.php?page=register"><strong>Daftar Sekarang</strong></a>
  </p>
  <div class="divider"></div>
  <div style="background:#f8fafc;border-radius:8px;padding:.875rem;font-size:.78rem;color:var(--muted)">
    <strong>Demo:</strong> Admin: <code>admin@kretakita.com</code> / <code>password</code> &nbsp;|&nbsp;
    User: <code>user@kretakita.com</code> / <code>password</code>
  </div>
</form>
<?php }

// ============================================================
// VIEW: Register
// ============================================================
function renderRegisterForm(): void { ?>
<h2 class="text-center" style="margin-bottom:.25rem">Buat Akun Baru</h2>
<p class="text-center text-muted text-sm" style="margin-bottom:1.5rem">Daftar dan mulai pesan tiket kereta</p>
<form method="POST" action="index.php?page=register">
  <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
  <div class="form-group">
    <label class="form-label">Nama Lengkap <span>*</span></label>
    <input type="text" name="name" class="form-control" placeholder="Masukkan nama lengkap" required value="<?= e($_POST['name']??'') ?>">
  </div>
  <div class="form-group">
    <label class="form-label">Email <span>*</span></label>
    <input type="email" name="email" class="form-control" placeholder="contoh@email.com" required value="<?= e($_POST['email']??'') ?>">
  </div>
  <div class="form-group">
    <label class="form-label">Password <span>*</span></label>
    <input type="password" name="password" class="form-control" placeholder="Minimal 6 karakter" required>
  </div>
  <div class="form-group">
    <label class="form-label">Konfirmasi Password <span>*</span></label>
    <input type="password" name="confirm_password" class="form-control" placeholder="Ulangi password" required>
  </div>
  <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-bottom:1rem">📝 Daftar Sekarang</button>
  <p class="text-center text-sm text-muted">
    Sudah punya akun? <a href="index.php?page=login"><strong>Masuk</strong></a>
  </p>
</form>
<?php }

// ============================================================
// VIEW: User Dashboard
// ============================================================
function renderUserDashboard(array $d): void {
    $bookings    = $d['bookings'] ?? [];
    $totalBooked = $d['totalBooked'] ?? 0;
    $totalPaid   = $d['totalPaid'] ?? 0;
    $userName    = $_SESSION['name'] ?? ''; ?>
<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-icon si-blue">🎫</div>
    <div class="stat-info"><p>Total Pemesanan</p><h2><?= $totalBooked ?></h2></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon si-green">✅</div>
    <div class="stat-info"><p>Tiket Lunas</p><h2><?= $totalPaid ?></h2></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon si-orange">⏳</div>
    <div class="stat-info"><p>Menunggu Bayar</p><h2><?= count(array_filter($bookings,fn($b)=>$b['payment_status']==='Pending')) ?></h2></div>
  </div>
</div>

<!-- Quick Actions -->
<div class="card mb-4">
  <div class="card-body" style="display:flex;gap:1rem;align-items:center;flex-wrap:wrap">
    <div style="flex:1;min-width:200px">
      <h3 style="margin-bottom:.25rem">Halo, <?= e($userName) ?>! 👋</h3>
      <p class="text-muted text-sm">Mau kemana hari ini? Pesan tiket keretamu sekarang.</p>
    </div>
    <a href="index.php?page=search" class="btn btn-primary btn-lg">🔍 Cari Jadwal Kereta</a>
  </div>
</div>

<!-- Recent Bookings -->
<div class="card">
  <div class="card-header">
    <h3>🎫 Pemesanan Terbaru</h3>
    <a href="index.php?page=my_bookings" class="btn btn-outline btn-sm">Lihat Semua</a>
  </div>
  <?php if (empty($bookings)): ?>
    <div class="empty-state">
      <div class="empty-icon">🎫</div>
      <h3>Belum Ada Pemesanan</h3>
      <p>Cari jadwal dan pesan tiket kereta pertamamu!</p>
      <a href="index.php?page=search" class="btn btn-primary">🔍 Cari Jadwal</a>
    </div>
  <?php else: ?>
  <div class="table-wrapper">
    <table>
      <thead><tr>
        <th>Kode Booking</th><th>Rute</th><th>Kereta</th><th>Tanggal</th><th>Kursi</th><th>Harga</th><th>Status</th><th>Aksi</th>
      </tr></thead>
      <tbody>
      <?php foreach (array_slice($bookings,0,5) as $bk): ?>
      <tr>
        <td><code style="font-weight:700;color:var(--primary)"><?= e($bk['booking_code']) ?></code></td>
        <td><strong><?= e($bk['origin']) ?></strong> → <strong><?= e($bk['destination']) ?></strong></td>
        <td><?= e($bk['train_name']) ?></td>
        <td><?= fmtDate($bk['departure_time']) ?> <?= fmtTime($bk['departure_time']) ?></td>
        <td><span style="font-weight:700"><?= e($bk['seat_number']) ?></span></td>
        <td><?= rupiah($bk['price']) ?></td>
        <td><span class="badge-pill badge-<?= strtolower($bk['payment_status']) ?>"><?= e($bk['payment_status']) ?></span></td>
        <td><a href="index.php?page=ticket&id=<?= $bk['id'] ?>" class="btn btn-sm btn-outline">🎫 Tiket</a></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php }

// ============================================================
// VIEW: Search
// ============================================================
function renderSearch(array $d): void {
    $origins  = $d['origins'] ?? [];
    $dests    = $d['dests'] ?? [];
    $results  = $d['results'] ?? [];
    $searched = $d['searched'] ?? false;
    $origin   = $d['origin'] ?? '';
    $dest     = $d['dest'] ?? '';
    $date     = $d['date'] ?? ''; ?>
<div class="search-hero">
  <h2>🔍 Cari Jadwal Kereta</h2>
  <p>Temukan perjalanan terbaik untuk destinasimu</p>
  <form method="GET" action="index.php">
    <input type="hidden" name="page" value="search">
    <div class="search-grid">
      <div class="form-group" style="margin-bottom:0">
        <label class="form-label">Kota Asal</label>
        <select name="origin" class="form-control" required>
          <option value="">-- Pilih Kota Asal --</option>
          <?php foreach ($origins as $o): ?>
          <option value="<?= e($o) ?>" <?= $origin===$o?'selected':'' ?>><?= e($o) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group" style="margin-bottom:0">
        <label class="form-label">Kota Tujuan</label>
        <select name="destination" class="form-control" required>
          <option value="">-- Pilih Kota Tujuan --</option>
          <?php foreach ($dests as $dest2): ?>
          <option value="<?= e($dest2) ?>" <?= $dest===$dest2?'selected':'' ?>><?= e($dest2) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group" style="margin-bottom:0">
        <label class="form-label">Tanggal Berangkat</label>
        <input type="date" name="date" class="form-control" required value="<?= e($date) ?>" min="<?= date('Y-m-d') ?>">
      </div>
      <div>
        <button type="submit" class="btn btn-primary btn-lg" style="white-space:nowrap">🔍 Cari</button>
      </div>
    </div>
  </form>
</div>

<?php if ($searched): ?>
  <div class="flex-between mb-3">
    <h3><?= count($results) > 0 ? count($results).' jadwal ditemukan' : '0 jadwal ditemukan' ?></h3>
    <?php if ($origin && $dest && $date): ?>
    <p class="text-muted text-sm"><?= e($origin) ?> → <?= e($dest) ?> | <?= fmtDate($date) ?></p>
    <?php endif; ?>
  </div>
  <?php if (empty($results)): ?>
    <div class="empty-state card"><div class="card-body">
      <div class="empty-icon">🚫</div>
      <h3>Jadwal Tidak Tersedia</h3>
      <p>Tidak ada jadwal kereta tersedia untuk rute dan tanggal yang dipilih.</p>
    </div></div>
  <?php else: ?>
    <div class="schedule-list">
      <?php foreach ($results as $s): ?>
      <div class="schedule-card">
        <div class="train-logo">🚃</div>
        <div class="schedule-route">
          <div class="route-line">
            <span class="city-name"><?= e($s['origin']) ?></span>
            <span class="route-arrow">→</span>
            <span class="city-name"><?= e($s['destination']) ?></span>
          </div>
          <div class="route-meta">
            <span>🚂 <?= e($s['train_name']) ?></span>
            <span>💺 <?= $s['available_seats'] ?> kursi tersedia</span>
          </div>
        </div>
        <div class="schedule-time">
          <div class="time-display"><?= fmtTime($s['departure_time']) ?></div>
          <div class="time-label">Berangkat</div>
        </div>
        <div class="schedule-duration" style="padding:0 1.25rem;text-align:center">
          <div style="font-size:.75rem;color:var(--muted)">──────</div>
          <div style="font-size:.7rem;color:var(--muted)">
            <?php
            $diff = abs(strtotime($s['arrival_time']) - strtotime($s['departure_time']));
            $h = floor($diff/3600); $m = floor(($diff%3600)/60);
            echo "{$h}j {$m}m";
            ?>
          </div>
        </div>
        <div class="schedule-time">
          <div class="time-display"><?= fmtTime($s['arrival_time']) ?></div>
          <div class="time-label">Tiba</div>
        </div>
        <div class="schedule-price" style="border-left:1px solid var(--border);padding-left:1.25rem">
          <div class="price-amount"><?= rupiah($s['price']) ?></div>
          <div class="price-label">per orang</div>
        </div>
        <div>
          <a href="index.php?page=schedule_detail&id=<?= $s['id'] ?>" class="btn btn-primary">Pilih Kursi</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
<?php else: ?>
  <div class="alert alert-info"><span class="alert-icon">ℹ️</span><span>Silakan isi form pencarian di atas untuk melihat jadwal yang tersedia.</span></div>
<?php endif; ?>
<?php }

// ============================================================
// VIEW: Schedule Detail + Seat Selection
// ============================================================
function renderScheduleDetail(array $d): void {
    $s           = $d['schedule'];
    $bookedSeats = $d['bookedSeats'] ?? [];
    $totalSeats  = 20;
    $diff = abs(strtotime($s['arrival_time']) - strtotime($s['departure_time']));
    $h = floor($diff/3600); $m = floor(($diff%3600)/60); ?>
<div class="grid-2" style="gap:1.5rem">
  <!-- Train Info -->
  <div>
    <div class="card mb-4">
      <div class="card-header"><h3>🚂 Info Kereta</h3></div>
      <div class="card-body">
        <div style="font-size:2rem;text-align:center;margin-bottom:1rem">🚃</div>
        <h2 style="text-align:center;margin-bottom:1.5rem"><?= e($s['train_name']) ?></h2>
        <div class="flex-between" style="margin-bottom:.75rem">
          <div style="text-align:center;flex:1">
            <div style="font-size:1.75rem;font-weight:900"><?= e($s['origin']) ?></div>
            <div class="text-muted text-sm">Keberangkatan</div>
            <div style="font-size:1.25rem;font-weight:800;color:var(--primary)"><?= fmtTime($s['departure_time']) ?></div>
            <div class="text-xs text-muted"><?= fmtDate($s['departure_time']) ?></div>
          </div>
          <div style="padding:0 1rem;text-align:center;color:var(--muted)">
            <div>──────</div>
            <div class="text-xs"><?= $h ?>j <?= $m ?>m</div>
          </div>
          <div style="text-align:center;flex:1">
            <div style="font-size:1.75rem;font-weight:900"><?= e($s['destination']) ?></div>
            <div class="text-muted text-sm">Kedatangan</div>
            <div style="font-size:1.25rem;font-weight:800;color:var(--success)"><?= fmtTime($s['arrival_time']) ?></div>
            <div class="text-xs text-muted"><?= fmtDate($s['arrival_time']) ?></div>
          </div>
        </div>
        <div class="divider"></div>
        <div class="flex-between">
          <span class="text-muted text-sm">Harga per Tiket</span>
          <span style="font-size:1.25rem;font-weight:800;color:var(--primary)"><?= rupiah($s['price']) ?></span>
        </div>
        <div class="flex-between mt-2">
          <span class="text-muted text-sm">Kursi Tersedia</span>
          <span style="font-weight:700"><?= $s['available_seats'] ?> kursi</span>
        </div>
      </div>
    </div>
  </div>

  <!-- Seat Selection -->
  <div>
    <div class="card">
      <div class="card-header"><h3>💺 Pilih Kursi</h3></div>
      <div class="card-body">
        <div class="seat-legend">
          <div class="legend-item"><div class="legend-box legend-available"></div><span>Tersedia</span></div>
          <div class="legend-item"><div class="legend-box legend-booked"></div><span>Terpesan</span></div>
          <div class="legend-item"><div class="legend-box legend-selected"></div><span>Dipilih</span></div>
        </div>
        <div style="background:#f8fafc;border-radius:10px;padding:1rem;margin-bottom:1rem">
          <div style="text-align:center;font-size:.75rem;color:var(--muted);margin-bottom:.75rem;text-transform:uppercase;letter-spacing:1px">🪟 Jendela — Lorong — Lorong — Jendela 🪟</div>
          <div class="seat-grid">
            <?php for ($i=1; $i<=$totalSeats; $i++):
              $seatLabel = 'S'.str_pad($i,2,'0',STR_PAD_LEFT);
              $isBooked  = in_array($seatLabel, $bookedSeats);
              $col       = (($i-1) % 4) + 1;
            ?>
            <button type="button"
              class="seat-btn <?= $isBooked ? 'booked' : '' ?>"
              data-seat="<?= $seatLabel ?>"
              <?= $isBooked ? 'disabled' : '' ?>>
              <?= $seatLabel ?>
            </button>
            <?php if ($col === 2): ?><div style="width:30px"></div><?php endif; ?>
            <?php endfor; ?>
          </div>
        </div>

        <form method="POST" action="index.php?page=book" id="bookingForm">
          <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
          <input type="hidden" name="schedule_id" value="<?= $s['id'] ?>">
          <input type="hidden" name="seat_number" id="selectedSeatInput" value="">
          <div class="form-group">
            <label class="form-label">Kursi Dipilih</label>
            <input type="text" id="selectedSeatDisplay" class="form-control" placeholder="Klik kursi di atas" readonly style="cursor:default;font-weight:700;font-size:1.1rem;text-align:center">
          </div>
          <button type="submit" class="btn btn-primary btn-block btn-lg" id="bookBtn" disabled>
            🎫 Pesan Tiket Sekarang
          </button>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
(function(){
  const seats = document.querySelectorAll('.seat-btn:not(.booked)');
  const input = document.getElementById('selectedSeatInput');
  const display = document.getElementById('selectedSeatDisplay');
  const btn = document.getElementById('bookBtn');
  let selected = null;
  seats.forEach(seat => {
    seat.addEventListener('click', function(){
      if(selected) selected.classList.remove('selected');
      selected = this;
      this.classList.add('selected');
      const s = this.dataset.seat;
      input.value = s;
      display.value = s + ' — Tersedia';
      btn.disabled = false;
    });
  });
  document.getElementById('bookingForm').addEventListener('submit',function(e){
    if(!input.value){ e.preventDefault(); alert('Pilih kursi terlebih dahulu!'); }
  });
})();
</script>
<?php }

// ============================================================
// VIEW: Payment
// ============================================================
function renderPayment(array $d): void {
    $schedule = $d['schedule'];
    $seat     = $d['seat']; ?>
<div class="payment-card">
  <div class="card">
    <div class="card-header" style="background:linear-gradient(135deg,var(--dark),var(--dark2));color:white;border-radius:var(--radius) var(--radius) 0 0">
      <h3 style="color:white">💳 Konfirmasi Pembayaran</h3>
      <span class="text-sm" style="color:rgba(255,255,255,.6)">Selesaikan pemesanan Anda</span>
    </div>
    <div class="card-body">
      <div class="payment-summary">
        <h3 style="margin-bottom:.75rem;color:var(--primary)">📋 Ringkasan Pemesanan</h3>
        <div class="payment-row"><span class="text-muted">Kereta</span><strong><?= e($schedule['train_name']) ?></strong></div>
        <div class="payment-row"><span class="text-muted">Rute</span><strong><?= e($schedule['origin']) ?> → <?= e($schedule['destination']) ?></strong></div>
        <div class="payment-row"><span class="text-muted">Tanggal</span><strong><?= fmtDate($schedule['departure_time']) ?></strong></div>
        <div class="payment-row"><span class="text-muted">Waktu</span><strong><?= fmtTime($schedule['departure_time']) ?> - <?= fmtTime($schedule['arrival_time']) ?></strong></div>
        <div class="payment-row"><span class="text-muted">Nomor Kursi</span><strong><?= e($seat) ?></strong></div>
        <div class="payment-row"><span class="text-muted">Penumpang</span><strong><?= e($_SESSION['name']) ?></strong></div>
        <div class="payment-row total"><span>Total Pembayaran</span><span><?= rupiah($schedule['price']) ?></span></div>
      </div>

      <h3 style="margin-bottom:.75rem">Pilih Metode Pembayaran</h3>
      <div class="payment-methods">
        <div class="payment-method-btn selected" onclick="selectPayment(this)">
          <div class="pm-icon">🏦</div>
          <div><div class="pm-name">Transfer Bank</div><div class="pm-desc">BCA, Mandiri, BNI</div></div>
        </div>
        <div class="payment-method-btn" onclick="selectPayment(this)">
          <div class="pm-icon">💰</div>
          <div><div class="pm-name">E-Wallet</div><div class="pm-desc">GoPay, OVO, DANA</div></div>
        </div>
        <div class="payment-method-btn" onclick="selectPayment(this)">
          <div class="pm-icon">💳</div>
          <div><div class="pm-name">Kartu Kredit</div><div class="pm-desc">Visa / Mastercard</div></div>
        </div>
        <div class="payment-method-btn" onclick="selectPayment(this)">
          <div class="pm-icon">🏪</div>
          <div><div class="pm-name">Minimarket</div><div class="pm-desc">Indomaret, Alfamart</div></div>
        </div>
      </div>

      <div class="alert alert-info" style="margin-bottom:1.25rem">
        <span class="alert-icon">ℹ️</span>
        <span>Ini adalah simulasi pembayaran. Klik <strong>Bayar Sekarang</strong> untuk menyelesaikan pemesanan dan tiket akan langsung diterbitkan.</span>
      </div>

      <form method="POST" action="index.php?page=pay_confirm">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <div style="display:flex;gap:.75rem">
          <a href="index.php?page=schedule_detail&id=<?= $schedule['id'] ?>" class="btn btn-secondary btn-lg" style="flex:1;text-align:center">← Kembali</a>
          <button type="submit" class="btn btn-success btn-lg" style="flex:2">
            ✅ Bayar <?= rupiah($schedule['price']) ?>
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<script>
function selectPayment(el){
  document.querySelectorAll('.payment-method-btn').forEach(b=>b.classList.remove('selected'));
  el.classList.add('selected');
}
</script>
<?php }

// ============================================================
// VIEW: Ticket (Digital)
// ============================================================
function renderTicket(array $d): void {
    $bk = $d['booking'];
    // Generate barcode visual (decorative)
    $barHeights = [40,20,30,15,45,25,35,10,50,30,20,40,25,35,15,45,30,20,40,25]; ?>
<div class="no-print" style="margin-bottom:1.5rem;display:flex;gap:1rem;flex-wrap:wrap">
  <button onclick="window.print()" class="btn btn-primary">🖨️ Cetak Tiket</button>
  <a href="index.php?page=my_bookings" class="btn btn-secondary">← Kembali ke Pemesanan</a>
</div>
<div class="ticket-wrapper">
  <div class="ticket-top">
    <div class="ticket-header">
      <div class="ticket-brand">
        <span style="font-size:1.5rem">🚂</span>
        <h2><?= APP_NAME ?></h2>
      </div>
      <span class="badge-pill badge-<?= strtolower($bk['payment_status']) ?>"><?= $bk['payment_status'] ?></span>
    </div>
    <div class="ticket-route">
      <div class="ticket-city">
        <div class="city-code"><?= strtoupper(substr($bk['origin'],0,3)) ?></div>
        <div class="city-full"><?= e($bk['origin']) ?></div>
        <div style="font-size:1.25rem;font-weight:700;margin-top:.25rem"><?= fmtTime($bk['departure_time']) ?></div>
      </div>
      <div class="ticket-divider">
        <div class="plane-icon">🚃</div>
      </div>
      <div class="ticket-city" style="text-align:right">
        <div class="city-code"><?= strtoupper(substr($bk['destination'],0,3)) ?></div>
        <div class="city-full"><?= e($bk['destination']) ?></div>
        <div style="font-size:1.25rem;font-weight:700;margin-top:.25rem"><?= fmtTime($bk['arrival_time']) ?></div>
      </div>
    </div>
  </div>

  <div class="ticket-body">
    <div class="ticket-details">
      <div class="ticket-detail-item">
        <p>Penumpang</p>
        <h4><?= e($bk['user_name']) ?></h4>
      </div>
      <div class="ticket-detail-item">
        <p>No. Kereta</p>
        <h4><?= e($bk['train_name']) ?></h4>
      </div>
      <div class="ticket-detail-item">
        <p>No. Kursi</p>
        <h4 style="color:var(--primary);font-size:1.25rem"><?= e($bk['seat_number']) ?></h4>
      </div>
      <div class="ticket-detail-item">
        <p>Tanggal</p>
        <h4><?= fmtDate($bk['departure_time']) ?></h4>
      </div>
      <div class="ticket-detail-item">
        <p>Waktu Berangkat</p>
        <h4><?= fmtTime($bk['departure_time']) ?> WIB</h4>
      </div>
      <div class="ticket-detail-item">
        <p>Harga</p>
        <h4 style="color:var(--success)"><?= rupiah($bk['price']) ?></h4>
      </div>
    </div>

    <div class="ticket-cut"></div>
    <div class="ticket-barcode">
      <div class="barcode-lines">
        <?php foreach ($barHeights as $bh): ?>
        <span style="height:<?= $bh ?>px"></span>
        <?php endforeach; ?>
      </div>
      <div class="booking-code-display"><?= e($bk['booking_code']) ?></div>
      <div class="text-xs text-muted" style="margin-top:.25rem">Kode Booking</div>
    </div>
  </div>
</div>
<?php }

// ============================================================
// VIEW: My Bookings
// ============================================================
function renderMyBookings(array $d): void {
    $bookings = $d['bookings'] ?? []; ?>
<div class="card">
  <div class="card-header">
    <h3>🎫 Riwayat Pemesanan Saya</h3>
    <a href="index.php?page=search" class="btn btn-primary btn-sm">+ Pesan Baru</a>
  </div>
  <?php if (empty($bookings)): ?>
    <div class="empty-state">
      <div class="empty-icon">🎫</div>
      <h3>Belum Ada Pemesanan</h3>
      <p>Anda belum pernah memesan tiket kereta.</p>
      <a href="index.php?page=search" class="btn btn-primary">🔍 Cari Jadwal</a>
    </div>
  <?php else: ?>
  <div class="table-wrapper">
    <table>
      <thead><tr>
        <th>#</th><th>Kode Booking</th><th>Rute</th><th>Kereta</th><th>Tanggal</th><th>Kursi</th><th>Harga</th><th>Status</th><th>Aksi</th>
      </tr></thead>
      <tbody>
      <?php foreach ($bookings as $i=>$bk): ?>
      <tr>
        <td class="text-muted"><?= $i+1 ?></td>
        <td><code style="font-weight:700;color:var(--primary);font-size:.875rem"><?= e($bk['booking_code']) ?></code></td>
        <td><strong><?= e($bk['origin']) ?></strong> <span class="text-muted">→</span> <strong><?= e($bk['destination']) ?></strong></td>
        <td><?= e($bk['train_name']) ?></td>
        <td><?= fmtDate($bk['departure_time']) ?><br><span class="text-xs text-muted"><?= fmtTime($bk['departure_time']) ?></span></td>
        <td><strong><?= e($bk['seat_number']) ?></strong></td>
        <td><strong><?= rupiah($bk['price']) ?></strong></td>
        <td><span class="badge-pill badge-<?= strtolower($bk['payment_status']) ?>"><?= e($bk['payment_status']) ?></span></td>
        <td>
          <a href="index.php?page=ticket&id=<?= $bk['id'] ?>" class="btn btn-sm btn-outline">🎫 Tiket</a>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php }

// ============================================================
// VIEW: Admin Dashboard
// ============================================================
function renderAdminDashboard(array $d): void {
    $totalUsers    = $d['totalUsers'] ?? 0;
    $totalBookings = $d['totalBookings'] ?? 0;
    $totalRevenue  = $d['totalRevenue'] ?? 0;
    $totalTrains   = $d['totalTrains'] ?? 0;
    $recentBookings= $d['recentBookings'] ?? [];
    $bookingStats  = $d['bookingStats'] ?? []; ?>
<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-icon si-blue">👥</div>
    <div class="stat-info"><p>Total Pengguna</p><h2><?= number_format($totalUsers) ?></h2></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon si-orange">🎫</div>
    <div class="stat-info"><p>Total Pemesanan</p><h2><?= number_format($totalBookings) ?></h2></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon si-green">💰</div>
    <div class="stat-info"><p>Total Pendapatan</p><h2 style="font-size:1.1rem"><?= rupiah($totalRevenue) ?></h2></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon si-purple">🚂</div>
    <div class="stat-info"><p>Armada Kereta</p><h2><?= number_format($totalTrains) ?></h2></div>
  </div>
</div>

<div class="grid-2">
  <!-- Booking Stats Chart (CSS-based) -->
  <div class="card">
    <div class="card-header"><h3>📊 Status Pemesanan</h3></div>
    <div class="card-body">
      <?php
      $total = array_sum($bookingStats);
      $statItems = [
        ['label'=>'Paid','color'=>'var(--success)','icon'=>'✅'],
        ['label'=>'Pending','color'=>'var(--warning)','icon'=>'⏳'],
        ['label'=>'Cancelled','color'=>'var(--danger)','icon'=>'❌'],
      ];
      foreach ($statItems as $si):
        $cnt  = $bookingStats[$si['label']] ?? 0;
        $pct  = $total > 0 ? round($cnt/$total*100) : 0;
      ?>
      <div style="margin-bottom:1rem">
        <div class="flex-between text-sm" style="margin-bottom:.35rem">
          <span><?= $si['icon'] ?> <?= $si['label'] ?></span>
          <span style="font-weight:700"><?= $cnt ?> <span class="text-muted">(<?= $pct ?>%)</span></span>
        </div>
        <div style="height:10px;background:#f1f5f9;border-radius:50px;overflow:hidden">
          <div style="height:100%;width:<?= $pct ?>%;background:<?= $si['color'] ?>;border-radius:50px;transition:width .3s"></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Quick Links -->
  <div class="card">
    <div class="card-header"><h3>⚡ Akses Cepat</h3></div>
    <div class="card-body" style="display:flex;flex-direction:column;gap:.75rem">
      <a href="index.php?page=admin_train_form" class="btn btn-primary">➕ Tambah Kereta Baru</a>
      <a href="index.php?page=admin_schedule_form" class="btn btn-outline">➕ Tambah Jadwal Baru</a>
      <a href="index.php?page=admin_bookings" class="btn btn-secondary">📋 Kelola Pemesanan</a>
      <a href="index.php?page=admin_trains" class="btn btn-secondary">🚂 Daftar Kereta</a>
    </div>
  </div>
</div>

<!-- Recent Bookings -->
<div class="card mt-4">
  <div class="card-header">
    <h3>🔔 Pemesanan Terbaru</h3>
    <a href="index.php?page=admin_bookings" class="btn btn-outline btn-sm">Lihat Semua</a>
  </div>
  <?php if (empty($recentBookings)): ?>
    <div class="empty-state"><div class="empty-icon">📭</div><p class="text-muted">Belum ada pemesanan</p></div>
  <?php else: ?>
  <div class="table-wrapper">
    <table>
      <thead><tr><th>Kode</th><th>Penumpang</th><th>Rute</th><th>Kereta</th><th>Tanggal</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($recentBookings as $bk): ?>
      <tr>
        <td><code style="font-weight:700;color:var(--primary)"><?= e($bk['booking_code']) ?></code></td>
        <td><?= e($bk['user_name']) ?></td>
        <td><strong><?= e($bk['origin']) ?></strong> → <strong><?= e($bk['destination']) ?></strong></td>
        <td><?= e($bk['train_name']) ?></td>
        <td><?= fmtDate($bk['departure_time']) ?> <?= fmtTime($bk['departure_time']) ?></td>
        <td><span class="badge-pill badge-<?= strtolower($bk['payment_status']) ?>"><?= e($bk['payment_status']) ?></span></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php }

// ============================================================
// VIEW: Admin Trains
// ============================================================
function renderAdminTrains(array $d): void {
    $trains = $d['trains'] ?? []; ?>
<div class="card">
  <div class="card-header">
    <h3>🚂 Daftar Kereta (<?= count($trains) ?>)</h3>
    <a href="index.php?page=admin_train_form" class="btn btn-primary btn-sm">➕ Tambah Kereta</a>
  </div>
  <?php if (empty($trains)): ?>
    <div class="empty-state"><div class="empty-icon">🚂</div><h3>Belum Ada Data Kereta</h3>
    <a href="index.php?page=admin_train_form" class="btn btn-primary">➕ Tambah Kereta</a></div>
  <?php else: ?>
  <div class="table-wrapper">
    <table>
      <thead><tr><th>#</th><th>Nama Kereta</th><th>Asal</th><th>Tujuan</th><th>Harga</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($trains as $i=>$t): ?>
      <tr>
        <td class="text-muted"><?= $i+1 ?></td>
        <td><strong>🚃 <?= e($t['train_name']) ?></strong></td>
        <td><?= e($t['origin']) ?></td>
        <td><?= e($t['destination']) ?></td>
        <td><strong style="color:var(--primary)"><?= rupiah($t['price']) ?></strong></td>
        <td style="display:flex;gap:.5rem">
          <a href="index.php?page=admin_train_form&id=<?= $t['id'] ?>" class="btn btn-sm btn-warning">✏️ Edit</a>
          <a href="index.php?page=admin_train_delete&id=<?= $t['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus kereta ini?')">🗑️</a>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php }

// ============================================================
// VIEW: Admin Train Form
// ============================================================
function renderAdminTrainForm(array $d): void {
    $t = $d['train'] ?? null;
    $isEdit = $t !== null; ?>
<div style="max-width:600px">
  <div class="card">
    <div class="card-header">
      <h3><?= $isEdit ? '✏️ Edit Kereta' : '➕ Tambah Kereta Baru' ?></h3>
    </div>
    <div class="card-body">
      <form method="POST" action="index.php?page=admin_train_save">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= $t['id'] ?>"><?php endif; ?>
        <div class="form-group">
          <label class="form-label">Nama Kereta <span>*</span></label>
          <input type="text" name="train_name" class="form-control" placeholder="cth: Argo Wilis Ekspres" required value="<?= e($t['train_name']??'') ?>">
        </div>
        <div class="form-row col-2">
          <div class="form-group">
            <label class="form-label">Kota Asal <span>*</span></label>
            <input type="text" name="origin" class="form-control" placeholder="cth: Jakarta" required value="<?= e($t['origin']??'') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Kota Tujuan <span>*</span></label>
            <input type="text" name="destination" class="form-control" placeholder="cth: Surabaya" required value="<?= e($t['destination']??'') ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Harga Tiket (Rp) <span>*</span></label>
          <input type="number" name="price" class="form-control" placeholder="cth: 250000" required min="1000" value="<?= e($t['price']??'') ?>">
        </div>
        <div style="display:flex;gap:.75rem;margin-top:1.5rem">
          <a href="index.php?page=admin_trains" class="btn btn-secondary">← Batal</a>
          <button type="submit" class="btn btn-primary" style="flex:1"><?= $isEdit ? '💾 Simpan Perubahan' : '➕ Tambah Kereta' ?></button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php }

// ============================================================
// VIEW: Admin Schedules
// ============================================================
function renderAdminSchedules(array $d): void {
    $schedules = $d['schedules'] ?? []; ?>
<div class="card">
  <div class="card-header">
    <h3>📅 Jadwal Keberangkatan (<?= count($schedules) ?>)</h3>
    <a href="index.php?page=admin_schedule_form" class="btn btn-primary btn-sm">➕ Tambah Jadwal</a>
  </div>
  <?php if (empty($schedules)): ?>
    <div class="empty-state"><div class="empty-icon">📅</div><h3>Belum Ada Jadwal</h3>
    <a href="index.php?page=admin_schedule_form" class="btn btn-primary">➕ Tambah Jadwal</a></div>
  <?php else: ?>
  <div class="table-wrapper">
    <table>
      <thead><tr><th>#</th><th>Kereta</th><th>Rute</th><th>Berangkat</th><th>Tiba</th><th>Kursi Tersedia</th><th>Harga</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($schedules as $i=>$s): ?>
      <tr>
        <td class="text-muted"><?= $i+1 ?></td>
        <td><strong>🚃 <?= e($s['train_name']) ?></strong></td>
        <td><?= e($s['origin']) ?> → <?= e($s['destination']) ?></td>
        <td><?= fmtDate($s['departure_time'],'d M Y') ?><br><strong><?= fmtTime($s['departure_time']) ?></strong></td>
        <td><?= fmtDate($s['arrival_time'],'d M Y') ?><br><strong><?= fmtTime($s['arrival_time']) ?></strong></td>
        <td>
          <span style="font-weight:700;color:<?= $s['available_seats']>5?'var(--success)':'var(--danger)' ?>">
            <?= $s['available_seats'] ?> kursi
          </span>
        </td>
        <td><?= rupiah($s['price']) ?></td>
        <td style="display:flex;gap:.5rem">
          <a href="index.php?page=admin_schedule_form&id=<?= $s['id'] ?>" class="btn btn-sm btn-warning">✏️</a>
          <a href="index.php?page=admin_schedule_delete&id=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus jadwal ini?')">🗑️</a>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php }

// ============================================================
// VIEW: Admin Schedule Form
// ============================================================
function renderAdminScheduleForm(array $d): void {
    $s      = $d['schedule'] ?? null;
    $trains = $d['trains'] ?? [];
    $isEdit = $s !== null; ?>
<div style="max-width:600px">
  <div class="card">
    <div class="card-header"><h3><?= $isEdit ? '✏️ Edit Jadwal' : '➕ Tambah Jadwal Baru' ?></h3></div>
    <div class="card-body">
      <form method="POST" action="index.php?page=admin_schedule_save">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= $s['id'] ?>"><?php endif; ?>
        <div class="form-group">
          <label class="form-label">Kereta <span>*</span></label>
          <select name="train_id" class="form-control" required>
            <option value="">-- Pilih Kereta --</option>
            <?php foreach ($trains as $t): ?>
            <option value="<?= $t['id'] ?>" <?= ($s['train_id']??'')==$t['id']?'selected':'' ?>>
              <?= e($t['train_name']) ?> (<?= e($t['origin']) ?> → <?= e($t['destination']) ?>)
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-row col-2">
          <div class="form-group">
            <label class="form-label">Waktu Berangkat <span>*</span></label>
            <input type="datetime-local" name="departure_time" class="form-control" required
              value="<?= e(isset($s['departure_time'])?date('Y-m-d\TH:i',strtotime($s['departure_time'])):'') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Waktu Tiba <span>*</span></label>
            <input type="datetime-local" name="arrival_time" class="form-control" required
              value="<?= e(isset($s['arrival_time'])?date('Y-m-d\TH:i',strtotime($s['arrival_time'])):'') ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Jumlah Kursi Tersedia <span>*</span></label>
          <input type="number" name="available_seats" class="form-control" min="1" max="100" required
            placeholder="cth: 20" value="<?= e($s['available_seats']??20) ?>">
          <p class="form-text">Maksimal 100 kursi per jadwal.</p>
        </div>
        <div style="display:flex;gap:.75rem;margin-top:1.5rem">
          <a href="index.php?page=admin_schedules" class="btn btn-secondary">← Batal</a>
          <button type="submit" class="btn btn-primary" style="flex:1"><?= $isEdit ? '💾 Simpan Perubahan' : '➕ Tambah Jadwal' ?></button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php }

// ============================================================
// VIEW: Admin Bookings
// ============================================================
function renderAdminBookings(array $d): void {
    $bookings = $d['bookings'] ?? [];
    $filter   = $d['filter'] ?? ''; ?>
<div class="card">
  <div class="card-header" style="flex-wrap:wrap;gap:.75rem">
    <h3>🎫 Manajemen Pemesanan (<?= count($bookings) ?>)</h3>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap">
      <a href="index.php?page=admin_bookings" class="btn btn-sm <?= !$filter?'btn-primary':'btn-secondary' ?>">Semua</a>
      <a href="index.php?page=admin_bookings&status=Paid" class="btn btn-sm <?= $filter==='Paid'?'btn-success':'btn-secondary' ?>">✅ Paid</a>
      <a href="index.php?page=admin_bookings&status=Pending" class="btn btn-sm <?= $filter==='Pending'?'btn-warning':'btn-secondary' ?>">⏳ Pending</a>
      <a href="index.php?page=admin_bookings&status=Cancelled" class="btn btn-sm <?= $filter==='Cancelled'?'btn-danger':'btn-secondary' ?>">❌ Cancelled</a>
    </div>
  </div>
  <?php if (empty($bookings)): ?>
    <div class="empty-state"><div class="empty-icon">📭</div><h3>Tidak Ada Pemesanan</h3></div>
  <?php else: ?>
  <div class="table-wrapper">
    <table>
      <thead><tr><th>#</th><th>Kode Booking</th><th>Penumpang</th><th>Rute</th><th>Kereta</th><th>Tanggal</th><th>Kursi</th><th>Harga</th><th>Status</th><th>Ubah Status</th></tr></thead>
      <tbody>
      <?php foreach ($bookings as $i=>$bk): ?>
      <tr>
        <td class="text-muted"><?= $i+1 ?></td>
        <td><code style="font-weight:700;color:var(--primary);font-size:.8rem"><?= e($bk['booking_code']) ?></code></td>
        <td>
          <strong><?= e($bk['user_name']) ?></strong><br>
          <span class="text-xs text-muted"><?= e($bk['user_email']) ?></span>
        </td>
        <td><?= e($bk['origin']) ?> → <?= e($bk['destination']) ?></td>
        <td><?= e($bk['train_name']) ?></td>
        <td><?= fmtDate($bk['departure_time']) ?><br><span class="text-xs text-muted"><?= fmtTime($bk['departure_time']) ?></span></td>
        <td><strong><?= e($bk['seat_number']) ?></strong></td>
        <td><?= rupiah($bk['price']) ?></td>
        <td><span class="badge-pill badge-<?= strtolower($bk['payment_status']) ?>"><?= e($bk['payment_status']) ?></span></td>
        <td>
          <form method="POST" action="index.php?page=admin_booking_status" style="display:flex;gap:.35rem;align-items:center">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="id" value="<?= $bk['id'] ?>">
            <select name="status" class="form-control" style="padding:.3rem .5rem;min-width:110px;font-size:.78rem">
              <option value="Pending" <?= $bk['payment_status']==='Pending'?'selected':'' ?>>Pending</option>
              <option value="Paid"    <?= $bk['payment_status']==='Paid'?'selected':'' ?>>Paid</option>
              <option value="Cancelled" <?= $bk['payment_status']==='Cancelled'?'selected':'' ?>>Cancelled</option>
            </select>
            <button type="submit" class="btn btn-sm btn-primary">✔</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php }
