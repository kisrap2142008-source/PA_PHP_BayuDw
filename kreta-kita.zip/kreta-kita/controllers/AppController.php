<?php
// ============================================================
// KRETA KITA — controllers/AppController.php
// Handles all request logic and delegates to views
// ============================================================

require_once __DIR__ . '/../models/AppModel.php';
require_once __DIR__ . '/../views/layout.php';

class AppController {

    private AppModel $model;

    public function __construct() {
        $this->model = new AppModel();
    }

    private function render(string $view, array $data = []): void {
        renderLayout($view, $data);
    }

    // ── AUTH ─────────────────────────────────────────────────
    public function login(): void {
        if (isLoggedIn()) redirect(isAdmin() ? 'admin_dashboard' : 'dashboard');
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verifyCsrf();
            $email    = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $errors   = [];
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email tidak valid.';
            if (strlen($password) < 6) $errors[] = 'Password minimal 6 karakter.';
            if (empty($errors)) {
                $user = $this->model->getUserByEmail($email);
                if ($user && password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['name']    = $user['name'];
                    $_SESSION['email']   = $user['email'];
                    $_SESSION['role']    = $user['role'];
                    flash('success', 'Selamat datang, ' . $user['name'] . '!');
                    redirect($user['role'] === 'admin' ? 'admin_dashboard' : 'dashboard');
                } else {
                    flash('error', 'Email atau password salah.');
                }
            } else {
                flash('error', implode(' ', $errors));
            }
        }
        $this->render('login');
    }

    public function register(): void {
        if (isLoggedIn()) redirect('dashboard');
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verifyCsrf();
            $name     = trim($_POST['name'] ?? '');
            $email    = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirm  = $_POST['confirm_password'] ?? '';
            $errors   = [];
            if (strlen($name) < 3) $errors[] = 'Nama minimal 3 karakter.';
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email tidak valid.';
            if (strlen($password) < 6) $errors[] = 'Password minimal 6 karakter.';
            if ($password !== $confirm) $errors[] = 'Konfirmasi password tidak cocok.';
            if (empty($errors)) {
                if ($this->model->getUserByEmail($email)) {
                    flash('error', 'Email sudah terdaftar. Gunakan email lain.');
                } else {
                    if ($this->model->createUser($name, $email, $password)) {
                        flash('success', 'Registrasi berhasil! Silakan login.');
                        redirect('login');
                    } else {
                        flash('error', 'Registrasi gagal. Coba lagi.');
                    }
                }
            } else {
                flash('error', implode(' ', $errors));
            }
        }
        $this->render('register');
    }

    public function logout(): void {
        session_destroy();
        flash('success', 'Anda telah berhasil logout.');
        redirect('login');
    }

    // ── USER DASHBOARD ───────────────────────────────────────
    public function userDashboard(): void {
        $bookings    = $this->model->getUserBookings((int)$_SESSION['user_id']);
        $totalBooked = count($bookings);
        $totalPaid   = count(array_filter($bookings, fn($b) => $b['payment_status'] === 'Paid'));
        $this->render('user_dashboard', compact('bookings','totalBooked','totalPaid'));
    }

    public function searchSchedules(): void {
        $origins  = $this->model->getAllOrigins();
        $dests    = $this->model->getAllDestinations();
        $results  = [];
        $searched = false;
        $origin   = trim($_GET['origin'] ?? '');
        $dest     = trim($_GET['destination'] ?? '');
        $date     = trim($_GET['date'] ?? '');
        if ($origin && $dest && $date) {
            $searched = true;
            $results  = $this->model->searchSchedules($origin, $dest, $date);
        }
        $this->render('search', compact('origins','dests','results','searched','origin','dest','date'));
    }

    public function scheduleDetail(): void {
        $id       = (int)($_GET['id'] ?? 0);
        $schedule = $this->model->getScheduleById($id);
        if (!$schedule) { flash('error','Jadwal tidak ditemukan.'); redirect('search'); }
        $bookedSeats = $this->model->getBookedSeats($id);
        $this->render('schedule_detail', compact('schedule','bookedSeats'));
    }

    public function bookTicket(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('search'); }
        verifyCsrf();
        $scheduleId = (int)($_POST['schedule_id'] ?? 0);
        $seat       = trim($_POST['seat_number'] ?? '');
        if (!$scheduleId || !$seat) { flash('error','Data tidak lengkap.'); redirect('search'); }
        $schedule = $this->model->getScheduleById($scheduleId);
        if (!$schedule) { flash('error','Jadwal tidak ditemukan.'); redirect('search'); }
        if ($this->model->isSeatTaken($scheduleId, $seat)) {
            flash('error', "Kursi {$seat} sudah dipesan. Pilih kursi lain.");
            redirect('schedule_detail', ['id' => $scheduleId]);
        }
        // Store in session for payment confirmation
        $_SESSION['pending_booking'] = [
            'schedule_id' => $scheduleId,
            'seat'        => $seat,
            'schedule'    => $schedule,
        ];
        redirect('payment');
    }

    public function payment(): void {
        if (empty($_SESSION['pending_booking'])) { redirect('search'); }
        $pending  = $_SESSION['pending_booking'];
        $schedule = $pending['schedule'];
        $seat     = $pending['seat'];
        $this->render('payment', compact('pending','schedule','seat'));
    }

    public function payConfirm(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('search'); }
        verifyCsrf();
        if (empty($_SESSION['pending_booking'])) { flash('error','Sesi pemesanan kedaluwarsa.'); redirect('search'); }
        $pending    = $_SESSION['pending_booking'];
        $scheduleId = $pending['schedule_id'];
        $seat       = $pending['seat'];
        $userId     = (int)$_SESSION['user_id'];
        $code       = generateBookingCode();
        $bookingId  = $this->model->createBooking($userId, $scheduleId, $seat, $code);
        if (!$bookingId) {
            flash('error', 'Pemesanan gagal. Kursi mungkin sudah diambil. Silakan pilih kursi lain.');
            unset($_SESSION['pending_booking']);
            redirect('schedule_detail', ['id' => $scheduleId]);
        }
        // Simulate payment — auto set to Paid
        $this->model->payBooking($bookingId);
        unset($_SESSION['pending_booking']);
        flash('success', "Pembayaran berhasil! Kode booking: {$code}");
        redirect('ticket', ['id' => $bookingId]);
    }

    public function viewTicket(): void {
        $id      = (int)($_GET['id'] ?? 0);
        $booking = $this->model->getBookingById($id);
        if (!$booking) { flash('error','Tiket tidak ditemukan.'); redirect('my_bookings'); }
        // Only owner or admin
        if (!isAdmin() && (int)$booking['user_id'] !== (int)$_SESSION['user_id']) {
            flash('error','Akses ditolak.'); redirect('my_bookings');
        }
        $this->render('ticket', compact('booking'));
    }

    public function myBookings(): void {
        $bookings = $this->model->getUserBookings((int)$_SESSION['user_id']);
        $this->render('my_bookings', compact('bookings'));
    }

    // ── ADMIN DASHBOARD ──────────────────────────────────────
    public function adminDashboard(): void {
        $totalUsers    = $this->model->countUsers();
        $totalBookings = $this->model->countBookings();
        $totalRevenue  = $this->model->totalRevenue();
        $totalTrains   = $this->model->countTrains();
        $recentBookings= $this->model->recentBookings(8);
        $bookingStats  = $this->model->bookingStats();
        $this->render('admin_dashboard', compact('totalUsers','totalBookings','totalRevenue','totalTrains','recentBookings','bookingStats'));
    }

    // ── ADMIN TRAINS ─────────────────────────────────────────
    public function adminTrains(): void {
        $trains = $this->model->getAllTrains();
        $this->render('admin_trains', compact('trains'));
    }

    public function adminTrainForm(): void {
        $train = null;
        $id    = (int)($_GET['id'] ?? 0);
        if ($id) {
            $train = $this->model->getTrainById($id);
            if (!$train) { flash('error','Kereta tidak ditemukan.'); redirect('admin_trains'); }
        }
        $this->render('admin_train_form', compact('train'));
    }

    public function adminTrainSave(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('admin_trains'); }
        verifyCsrf();
        $id    = (int)($_POST['id'] ?? 0);
        $name  = trim($_POST['train_name'] ?? '');
        $orig  = trim($_POST['origin'] ?? '');
        $dest  = trim($_POST['destination'] ?? '');
        $price = (float)($_POST['price'] ?? 0);
        if (!$name || !$orig || !$dest || $price <= 0) {
            flash('error','Semua field wajib diisi dengan benar.'); redirect($id ? 'admin_train_form' : 'admin_train_form', $id ? ['id'=>$id] : []);
        }
        if ($id) {
            $this->model->updateTrain($id,$name,$orig,$dest,$price);
            flash('success','Data kereta berhasil diperbarui.');
        } else {
            $this->model->createTrain($name,$orig,$dest,$price);
            flash('success','Kereta baru berhasil ditambahkan.');
        }
        redirect('admin_trains');
    }

    public function adminTrainDelete(): void {
        $id = (int)($_GET['id'] ?? 0);
        if ($id) { $this->model->deleteTrain($id); flash('success','Kereta berhasil dihapus.'); }
        redirect('admin_trains');
    }

    // ── ADMIN SCHEDULES ──────────────────────────────────────
    public function adminSchedules(): void {
        $schedules = $this->model->getAllSchedules();
        $this->render('admin_schedules', compact('schedules'));
    }

    public function adminScheduleForm(): void {
        $schedule = null;
        $id       = (int)($_GET['id'] ?? 0);
        if ($id) {
            $schedule = $this->model->getScheduleById($id);
            if (!$schedule) { flash('error','Jadwal tidak ditemukan.'); redirect('admin_schedules'); }
        }
        $trains = $this->model->getAllTrains();
        $this->render('admin_schedule_form', compact('schedule','trains'));
    }

    public function adminScheduleSave(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('admin_schedules'); }
        verifyCsrf();
        $id      = (int)($_POST['id'] ?? 0);
        $trainId = (int)($_POST['train_id'] ?? 0);
        $dep     = trim($_POST['departure_time'] ?? '');
        $arr     = trim($_POST['arrival_time'] ?? '');
        $seats   = (int)($_POST['available_seats'] ?? 0);
        if (!$trainId || !$dep || !$arr || $seats <= 0) {
            flash('error','Semua field wajib diisi dengan benar.'); redirect($id ? 'admin_schedule_form' : 'admin_schedule_form', $id ? ['id'=>$id] : []);
        }
        if ($id) {
            $this->model->updateSchedule($id,$trainId,$dep,$arr,$seats);
            flash('success','Jadwal berhasil diperbarui.');
        } else {
            $this->model->createSchedule($trainId,$dep,$arr,$seats);
            flash('success','Jadwal baru berhasil ditambahkan.');
        }
        redirect('admin_schedules');
    }

    public function adminScheduleDelete(): void {
        $id = (int)($_GET['id'] ?? 0);
        if ($id) { $this->model->deleteSchedule($id); flash('success','Jadwal berhasil dihapus.'); }
        redirect('admin_schedules');
    }

    // ── ADMIN BOOKINGS ───────────────────────────────────────
    public function adminBookings(): void {
        $filter   = trim($_GET['status'] ?? '');
        $bookings = $this->model->getAllBookings();
        if ($filter) $bookings = array_filter($bookings, fn($b) => $b['payment_status'] === $filter);
        $this->render('admin_bookings', compact('bookings','filter'));
    }

    public function adminBookingStatus(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('admin_bookings'); }
        verifyCsrf();
        $id     = (int)($_POST['id'] ?? 0);
        $status = trim($_POST['status'] ?? '');
        if ($id && $status) {
            $this->model->updateBookingStatus($id, $status);
            flash('success', "Status booking #$id diperbarui ke $status.");
        }
        redirect('admin_bookings');
    }
}
