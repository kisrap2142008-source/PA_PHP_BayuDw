<?php
// ============================================================
// KRETA KITA — index.php
// Application Entry Point & Router
// ============================================================

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/models/AppModel.php';
require_once __DIR__ . '/controllers/AppController.php';

$page = trim($_GET['page'] ?? '');
if (!$page) {
    $page = isLoggedIn() ? (isAdmin() ? 'admin_dashboard' : 'dashboard') : 'login';
}

$ctrl = new AppController();

// Route map
$routes = [
    // Public
    'login'                 => 'login',
    'register'              => 'register',
    'logout'                => 'logout',
    // User (requires login)
    'dashboard'             => ['user',   'userDashboard'],
    'search'                => ['user',   'searchSchedules'],
    'schedule_detail'       => ['user',   'scheduleDetail'],
    'book'                  => ['user',   'bookTicket'],
    'payment'               => ['user',   'payment'],
    'pay_confirm'           => ['user',   'payConfirm'],
    'ticket'                => ['user',   'viewTicket'],
    'my_bookings'           => ['user',   'myBookings'],
    // Admin (requires admin role)
    'admin_dashboard'       => ['admin',  'adminDashboard'],
    'admin_trains'          => ['admin',  'adminTrains'],
    'admin_train_form'      => ['admin',  'adminTrainForm'],
    'admin_train_save'      => ['admin',  'adminTrainSave'],
    'admin_train_delete'    => ['admin',  'adminTrainDelete'],
    'admin_schedules'       => ['admin',  'adminSchedules'],
    'admin_schedule_form'   => ['admin',  'adminScheduleForm'],
    'admin_schedule_save'   => ['admin',  'adminScheduleSave'],
    'admin_schedule_delete' => ['admin',  'adminScheduleDelete'],
    'admin_bookings'        => ['admin',  'adminBookings'],
    'admin_booking_status'  => ['admin',  'adminBookingStatus'],
];

if (!array_key_exists($page, $routes)) {
    $page = isLoggedIn() ? (isAdmin() ? 'admin_dashboard' : 'dashboard') : 'login';
}

$route = $routes[$page];

// Middleware
if (is_array($route)) {
    [$guard, $method] = $route;
    if ($guard === 'admin') {
        requireAdmin();
    } else {
        requireLogin();
    }
    $ctrl->$method();
} else {
    // Public route
    $ctrl->$route();
}
